﻿using ProgPoeDll;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static ProgPoeDll.Class1;

namespace ProgPart1
{
    /// <summary>
    /// Interaction logic for SemesterInformation.xaml
    /// </summary>
    public partial class SemesterInformation : Window
    {
       
        
        public SemesterInformation()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UserInformation information = new UserInformation();
            information.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
           





        }

        private void DataGrid2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            // confirm if entry is correct before sending to the DGV
            if (MessageBox.Show("Is the entry correct? ",
                "Confirm Entry", MessageBoxButton.YesNo)
                == MessageBoxResult.Yes)
            {
                //pull info from the boxes 

                semesterInput temp = new semesterInput();

                temp.day = Convert.ToInt32(dayTB.Text);
                temp.month = Convert.ToInt32(monthTB.Text);
                temp.name = courseTB.Text;
                temp.hoursWorked = Convert.ToInt32(hoursTB.Text);
                temp.startDate = Convert.ToDateTime(dateTB.Text);
                

                DataGrid2.Items.Add(temp);


            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            dayTB.Clear();
            monthTB.Clear();
            courseTB.Clear();
            hoursTB.Clear();
           
            
        }
    }
}
