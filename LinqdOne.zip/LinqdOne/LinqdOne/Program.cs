﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqdOne
{
    class Program
    {
        static void Main(string[] args)
        {

            //linq to iterate thru an array
            // int array --> hours spent
            Console.WriteLine("Unsorted array >>>");
            var values = new [] {2,9,12,76,24,64,8,5};

            //org display
            foreach (var element in values)
            {
                //literals / teneary
                Console.Write($"{element}" + " ");
            }

            //LINQ Query --> sorted in asc order
            var sorted =
                from value in values
                orderby value
                select value;

            //output
            Console.WriteLine("\n\nSorted array with LINQ >>>");
            foreach (var element in sorted)
            {
                //literals / teneary
                Console.Write($"{element}" + " ");
            }


            // find modules where you have spent more (>) than 5 hours per week 
            
            var filtered = 
                from value in values
                where value > 5
                select value;

            //output
            Console.WriteLine("\n\nModules -> 5 hours spent");
            foreach (var element in filtered)
            {
                //literals / teneary
                Console.Write($"{element}" + " ");
            }

            //sort the filtered array in desc order using LINQ
            var desc =
                from value in filtered
                orderby value descending
                select value;
           
            Console.WriteLine("\n\nSorted array with LINQ in descending order >>>");
            foreach (var element in desc)
            {
                //literals / teneary
                Console.Write($"{element}" + " ");
            }



            //sort the filtered array in asc order using LINQ
            var asc =
                from value in filtered
                orderby value ascending
                select value;

            Console.WriteLine("\n\nSorted array with LINQ in ascending order >>>");
            foreach (var element in asc)
            {
                //literals / teneary
                Console.Write($"{element}" + " ");
            }

            Console.ReadLine();     
        }
    }
}
