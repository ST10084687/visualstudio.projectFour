﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IceTask1Prog
{
    public partial class Form1 : Form
    {
        private LinkedList<Pages> pages;
        private LinkedListNode<Pages> currentPage;
        private int pageNumber;
        public Form1()
        {
            InitializeComponent();
            InitializeLinkedList();
            DisplayPage(currentPage);
        }
        private void InitializeLinkedList()
        {
            //data on each page
            Pages firstPg = new Pages() { Content = "Nowadays no one uses the library" };
            Pages secondPg = new Pages() { Content = "Instead Google and ChatGPT is the space for information" };
            Pages thirdPg = new Pages() { Content = "Libraries use a system of stocking books..." };
            Pages fourthPg = new Pages() { Content = "...Known as the Dewey Decimal..." };
            Pages fifthPg = new Pages() { Content = "...of numbering ... each book and category is given specific numbers" };
            Pages sixthPg = new Pages() { Content = "...and subjects" };

            pages = new LinkedList<Pages>();
            pages.AddLast(secondPg);
            LinkedListNode<Pages> nodepgFour = pages.AddLast(fourthPg);
            pages.AddLast(sixthPg);
            pages.AddLast(firstPg);
            pages.AddBefore(nodepgFour, thirdPg);
            pages.AddAfter(nodepgFour, fifthPg);

            currentPage = pages.First;
            pageNumber = 1;
        }

        private void DisplayPage(LinkedListNode<Pages> pageNode)
        {
            Pages page = pageNode.Value;

            // Clear previous content
            contentTextBox.Clear();

            // Display page content
            string content = page.Content;
            for (int i = 0; i < content.Length; i += 90)
            {
                string line = content.Substring(i);
                line = line.Length > 90 ? line.Substring(0, 90) : line;
                contentTextBox.AppendText(line + Environment.NewLine);
            }

            // Update page number and navigation buttons
            pageNumberLabel.Text = $" - {pageNumber} -";
            previousButton.Enabled = pageNode.Previous != null;
            nextButton.Enabled = pageNode.Next != null;
        }

        private void previousButton2_Click(object sender, EventArgs e)
        {
            if (currentPage.Previous != null)
            {
                currentPage = currentPage.Previous;
                pageNumber--;
                DisplayPage(currentPage);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void nextButton1_Click(object sender, EventArgs e)
        {
            if (currentPage.Next != null)
            {
                currentPage = currentPage.Next;
                pageNumber++;
                DisplayPage(currentPage);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(849, 449);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }
    }
}
