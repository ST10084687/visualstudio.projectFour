﻿using System.Collections.Generic;

namespace FlowersBrik_nMotor.Models
{
    public interface IFlowerCategoryRepository
    {
        IEnumerable<FlowerCategory> GetAllCategories { get; }
    }
}
