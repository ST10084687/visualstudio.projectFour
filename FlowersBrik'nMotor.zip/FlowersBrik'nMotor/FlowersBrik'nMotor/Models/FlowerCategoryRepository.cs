﻿using System.Collections.Generic;

namespace FlowersBrik_nMotor.Models
{
    public class FlowerCategoryRepository : IFlowerCategoryRepository
    {
        private readonly AppDbContext _appDbContext;

        public FlowerCategoryRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public IEnumerable<FlowerCategory> GetAllCategories => _appDbContext.FlowerCategory;
    }
}
