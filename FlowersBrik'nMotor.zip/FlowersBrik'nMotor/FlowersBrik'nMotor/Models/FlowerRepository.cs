﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace FlowersBrik_nMotor.Models
{
    public class FlowerRepository : IFlowerRepository
    { 
        private readonly AppDbContext _appDbContext;

       // ctor
    public FlowerRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        //use some of the properties 


        public IEnumerable<Flower> GetAllFlowers
        {
            get
            {
                return _appDbContext.Flowers.Include(s => s.flowerCategory);
            }
        }


        public IEnumerable<Flower> GetFlowersOnSale

        {
            get
            {
                return _appDbContext.Flowers.Include(s => s.flowerCategory).Where(c => c.IsOnSale);
            }
        }

        public Flower GetFlowerById(int flowerId)
        {
            return _appDbContext.Flowers.FirstOrDefault(s => s.flowerId == flowerId);

        }
    }
}
 
