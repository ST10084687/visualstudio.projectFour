﻿using System.Collections.Generic;

namespace FlowersBrik_nMotor.Models
{
    public class FlowerCategory
    {
        public int flowerCategoryId { get; set; }
        public string flowerCategoryName { get; set; }
        public string flowerCategoryDescription { get; set; }

        // property list --> each category will contain a sweet
        public List<Flower> flowers { get; set; }

    }

}
