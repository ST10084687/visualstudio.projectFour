﻿using System.Collections.Generic;

namespace FlowersBrik_nMotor.Models
{
    public interface IFlowerRepository
    {
        IEnumerable<Flower> GetAllFlowers { get; }
        IEnumerable<Flower> GetFlowersOnSale { get; }
        //how --> ID
        Flower GetFlowerById(int flowerId);
    }
}
