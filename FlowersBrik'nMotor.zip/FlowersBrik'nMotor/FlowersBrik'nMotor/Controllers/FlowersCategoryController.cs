﻿using FlowersBrik_nMotor.Models;
using Microsoft.AspNetCore.Mvc;

namespace FlowersBrik_nMotor.Controllers
{
    public class FlowersCategoryController : Controller
    {
        private readonly IFlowerRepository _flowerRepository;
        private readonly IFlowerCategoryRepository _flowerCategoryRepository;

        public FlowersCategoryController(IFlowerRepository flowerRepository, IFlowerCategoryRepository flowerCategoryRepository)
        {
            _flowerRepository = flowerRepository;
            _flowerCategoryRepository = flowerCategoryRepository;
        }

        public ViewResult List()
        {
            //has to return a view
            return View(_flowerCategoryRepository.GetAllCategories);
        }
    }
}
