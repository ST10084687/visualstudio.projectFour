﻿using FlowersBrik_nMotor.Models;
using FlowersBrik_nMotor.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace FlowersBrik_nMotor.Controllers
{
    public class FlowersController : Controller
    {
        private readonly IFlowerRepository _flowerRepository;
        private readonly IFlowerCategoryRepository _flowerCategoryRepository;

        public FlowersController(IFlowerRepository flowerRepository, IFlowerCategoryRepository flowerCategoryRepository)
        {
            _flowerRepository = flowerRepository;
            _flowerCategoryRepository = flowerCategoryRepository;
        }
        public IActionResult List()
        {
            // has to return a view 
            // return View(_sweetRepository.GetAllSweets);
            // consume the listviewModel -->.netcore
            var flowerListViewModel = new FlowerListViewModel();
            flowerListViewModel.Flowers = _flowerRepository.GetAllFlowers;
            flowerListViewModel.CurrentFlowerCateogry = "Tester";
            return View(flowerListViewModel);

        }
        public IActionResult Details(int id)
        {
            var flower = _flowerRepository.GetFlowerById(id);
            if (flower == null)
                return NotFound();

            return View(flower);
        }

    }
}
