﻿using FlowersBrik_nMotor.Models;
using System.Collections.Generic;

namespace FlowersBrik_nMotor.ViewModels
{
    public class FlowerListViewModel
    {
        public IEnumerable<Flower> Flowers { get; set; }
        public string CurrentFlowerCateogry { get; set; }
    }
}
