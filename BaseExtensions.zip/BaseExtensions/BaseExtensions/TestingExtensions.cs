﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseExtensions
{
    class TestingExtensions
    {
        //This will handle all method class for the full project 
        // with the org and extension methods working together 
        //add a main and pull ALL methods as if it was in the MAIN CLASS 

        static void Main()
        {
            Program p = new Program();
            p.methodOne();
            p.methodTwo();
            p.methodThree(); // extension method 

            Console.ReadLine();
        }
    }
}
