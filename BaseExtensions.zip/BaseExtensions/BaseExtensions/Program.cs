﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseExtensions
{
    class Program
    {
        static void Main(string[] args)
        {
            /* - - Project stage - unit testing
             * - - so you cannot change the code
             *    Inheritance -- only extends whats there
             *    - - prob -- cannot use it in sealed classes
             *    EXTENSION METHODS --> 
             *    --add code / add on methods to existing projects 
             *    
             *    Rules for extension methods -->
             *    1 -- all new code / methods must be in its own class - static
             *    2 -- all methods must be static 
             *    3 -- bind the original class to the new extension methods using a 
             *      Testing Class
             *      
             */

            Program p = new Program();
            p.methodOne();
            p.methodTwo();

            Console.ReadLine();
        }
        public void methodOne()
        {
            Console.WriteLine("From method one >>>");

        }
        public void methodTwo()
        {
            Console.WriteLine("From method two >>>");
        }
    }
}
