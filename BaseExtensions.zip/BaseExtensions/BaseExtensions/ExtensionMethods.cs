﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseExtensions
{
    static class ExtensionMethods
    {
        public static void methodThree(this Program p)
        {
            Console.WriteLine("From an extension method >>>");
        }
    }
}
