﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UserRegistration
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        User user = new User();
        Stack st = new Stack();
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            user.name = nameTB.Text;
            user.surname = surnameTB.Text;
            user.email = emailTB.Text;
            user.username = usernameTB.Text;
            user.password = passwordTB.Text;

            st.Push(user);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Mr" + user[0] + " " + user[1]+ " " + user[2] + " " + user[3] + " " + user[4] );
        }
    }
}
