﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BaseDll;

namespace UsingDll
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * -- Use the DLL file
             * -- Steps to follow:
             * 1--> Add a reference to the DLL file
             * 2--> Add a using statement to the base Dll
             * 3--> Add code that consumes the Dll
             * 4 --> If your Dll dosent show click on browse and the browse button and locate it and then add it and then click on okay
             */


            Console.WriteLine("Pulling from the DLL methods >>>");
            Console.WriteLine("The values 50 + 100: ");
            Console.WriteLine(BaseDll.Class1.addValues(50, 100));
            Console.WriteLine("The values 200 - 50: ");
            Console.WriteLine(BaseDll.Class1.addValues(200, 50));




            Console.ReadLine();
        }
    }
}
