﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleLinkedList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Data on eaach page 
            Pages firstPg = new Pages() { Content = "Nowadays no one uses the library........." };
            Pages secondPg = new Pages() { Content = "Use google.............." };
            Pages thirdPg = new Pages() { Content = "Use Chat GPT.........." };
            Pages fourthPg = new Pages() { Content = "Known as Dewey Decimal System........." };
            Pages fifthPg = new Pages() { Content = "Of numbering each book and categories........." };
            Pages sixthPg = new Pages() { Content = "and subject areas to study........." };


            //create the linked list
            LinkedList<Pages> pages = new LinkedList<Pages>();
            //now add pages onto the linked list
            pages.AddLast(secondPg);
            LinkedListNode<Pages> nodepgFour = pages.AddLast(fourthPg);
            pages.AddLast(sixthPg);
            pages.AddLast(firstPg);
            pages.AddBefore(nodepgFour, thirdPg);
            pages.AddAfter(nodepgFour, fifthPg);


            //iterations and printing
            LinkedListNode<Pages> current = pages.First;
            int number = 1;

            //when?
            while(current != null)
            {
                Console.Clear();
                string numString = $" - {number}";
                //console leading spaces 
                int leadSpaces = (90 - numString.Length)/2;
                Console.WriteLine(numString.PadLeft(leadSpaces + numString.Length));

                Console.WriteLine(); //leave a line
                //now print out the pages with its values

                string content = current.Value.Content;
                for (int i = 0; i < content.Length; i+=90)
                {
                    string line = content.Substring(i);
                    line = line.Length > 90 ? line.Substring(0,90) : line; //centre justify
                    Console.WriteLine(line);
                }

                Console.WriteLine();// lines

                Console.WriteLine($"Author \" N Ramckurran \", {Environment.NewLine} published 8/8/2023");

                Console.WriteLine();
                Console.WriteLine(current.Previous != null ? "PREVIOUS [P] " : GetSpaces(14));
                Console.WriteLine(current.Next != null ? "[N] NEXT > ".PadLeft(76) : string.Empty);

                //navigation
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.N:
                        if(current.Next != null)
                        {
                            current = current.Next;
                            number++;
                        }
                        break;

                      
                    case ConsoleKey.P:
                        if(current.Next != null)
                        {
                            current = current.Previous;
                            number--;
                        }
                        break;
                            default: return;
                }

            }
        }
        //method to handle spaciing 
        private static string GetSpaces(int number)
        {
            string result = string.Empty;
            for (int i = 0; i < number; i++)
            {
                result += "";

            }
            return result;

        }
    }
}
