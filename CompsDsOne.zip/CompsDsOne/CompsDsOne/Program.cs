﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompsDsOne
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            //lets add a simple array 
            int[] newArray = new int[100000];
            //populate
            for (int i = 0; i < newArray.Length; i++)
            {
                newArray[i] = i;
               // Console.Write(i + " ");
            }
            stopwatch.Stop();
            Console.WriteLine("The time taken by the array>>>>");
            Console.WriteLine(stopwatch.Elapsed);

            //comparison 
            //timer
            stopwatch.Restart();
            List<int> newList = new List<int>(100000);
            for (int i = 0; i < 100000; i++)
            {
                newList.Add(i);
              //  Console.Write(i + " ");
            }
            stopwatch.Stop();
            Console.WriteLine("The time taken by List<T>");
            Console.WriteLine(stopwatch.Elapsed);

            Console.ReadLine();
        }
    }
}
