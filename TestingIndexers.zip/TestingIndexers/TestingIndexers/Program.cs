﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingIndexers
{
    class Program
    {
        static void Main(string[] args)
        {
            //basic array    0  1  2   3   4   5
            int[] values = { 5, 7, 2, -3, 9, 14 };

            for (int i = 0; i < values.Length; i++)
            {
               
                Console.Write(values[i] + " ");

            }
            //Console.WriteLine();
            ////print out a single value
            //Console.WriteLine(values[2]); //pulling a value using its index

            Person p = new Person(1, "John", "Smith");
            //person class is treated like a virtual array
            Console.WriteLine("\n\nId: "+p[0]);
            Console.WriteLine("Name: " + p[1]);
            Console.WriteLine("Surname: " + p[2]);

            Console.ReadLine();



        }
    }
}
