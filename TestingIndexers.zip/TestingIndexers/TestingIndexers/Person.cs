﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingIndexers
{
    public class Person
    {
        // fields or objects 
        int personId;
        string firstName;
        string lastName;

        //constructor 
        public Person(int personId, string firstName, string lastName)
        {
            this.personId = personId;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        //indexer
        public object this [int index]
        {
            get
            {
                if (index == 0)
                    return personId;
                else if (index == 1)
                    return firstName;
                else if (index == 2)
                    return lastName;
                else return null;
            }
        }
    }
}
