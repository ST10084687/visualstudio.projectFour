﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathDll
{
    public class Class1
    {
        //methods 
        public int Addition (int valOne, int valTwo)
        {
            return valOne + valTwo;
        }
        public int Subtraction (int valOne, int valTwo)
        {
            return valOne - valTwo;
        }
        public int Multiplication(int valOne, int valTwo)
        {
            return valOne * valTwo;
        }
        public int Division(int valOne, int valTwo)
        {
            return valOne / valTwo;
        }
    }
}
