﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathDll;

namespace TestingDll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Class1 c = new Class1();

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //the add button code calc
            int temp= c.Addition(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox3.Text = temp.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int temp = c.Subtraction(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox3.Text = temp.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int temp = c.Multiplication(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox3.Text = temp.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int temp = c.Division(int.Parse(textBox1.Text), int.Parse(textBox2.Text));
            textBox3.Text = temp.ToString();
        }
    }
}
