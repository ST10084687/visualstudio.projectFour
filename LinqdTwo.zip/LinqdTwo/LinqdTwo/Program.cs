﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqdTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            //use employee class objects

            var employees = new[]
            {
                new Employee ("Jason", "Black", 50000 ),
                new Employee ("Sue", "Smith", 25000 ),
                new Employee ("James", "Green", 45000 ),
                new Employee ("Jackson", "Bourne", 50000 ),
                new Employee ("Matthew", "Hendricks", 35000 )
            };

            //using LINQ
            Console.WriteLine("The employee's details >>>>");
            foreach (var element in employees)
            {
                Console.WriteLine(element);
            }

            // order by first names
            Console.WriteLine("\n\n Ordered by first name>>>");
            var sortedNames =
                from e in employees
                orderby e.FirstName
                select e;

          //printing the query results
            foreach (var element in sortedNames)
            {
                
                Console.WriteLine(element);
            }
            
            // order by first names
            Console.WriteLine("\n\n Ordered by last name>>>");
            var lastname =
                from e in employees
                orderby e.LastName
                select e;

            //printing the query results
            foreach (var element in lastname)
            {

                Console.WriteLine(element);
            }

            Console.ReadLine();

        }
        
        }
    }

