﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqdTwo
{
    class Employee
    {
        //props
        public string FirstName { get; }//read only
        public string LastName { get; }//read only
        
        public decimal salary;


        //constructor 

        public Employee(string firstName, string lastName, decimal salary)
        {
            FirstName = firstName;
            LastName = lastName;
            this.salary = salary;
        }

        //method
        public decimal monthlySal
        {
            get
            {
                return salary;
            }
            set
            {
                if (value > 0)
                {
                    //stops salary from being negative
                    salary = value;
                }
            }
        }
        //output
        public override string ToString() =>
        
           // return base.ToString();

           $"{FirstName, 10} {LastName,10} {monthlySal, 10:C}";
        
    }
}
