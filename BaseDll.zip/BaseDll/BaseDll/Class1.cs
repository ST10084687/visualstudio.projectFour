﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseDll
{
    public class Class1
    {

        //METHODS 
        public static int addValues (int valOne, int valTwo)
        {
            return valOne + valTwo;
        }
        public static int minusValues(int valOne, int valTwo)
        {
            return valOne - valTwo;
        }


    }
}
// to find this click on build solution and then check in your bin file for it.
//make a copy and put it in notepad because you wont be able to see it afterwards.