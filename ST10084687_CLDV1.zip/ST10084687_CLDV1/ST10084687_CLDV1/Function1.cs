using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ST10084687_CLDV1
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = "Id/{id:int?}")] HttpRequest req,
            int? id, ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            var displayMessage = "";
            var genderM = "Male";
            var genderF = "Female";
            var vaccineDose1 = "1st Dose";
            var vaccineDose2 = "2nd Dose";
            var vaccineDose3 = "3rd Dose";
            var vaccineName1 = "Pfiser";
            var vaccineName2 = "Johnson and Johnson";
            var manufacturer1 = "Pfiser";
            var manufacturer2 = "Johnson and Johnson";
            var location1 = "Medi-Clinic";
            var location2 = "Dischem";
            var location3 = "Clicks";
            var location4 = "Westville Life Hospital";

            var details1 = "VACCINEE DETAILS";
            var details2 = "VACCINATOR DETAILS";
            var details3 = "VACCINE DOSE";
            var details4 = "VACCINE NAME";
            var details5 = "MANUFACTURER";
            var details6 = "BATCH NUMBER";
            var details7 = "VACCINE DATE";
            var details8 = "LOCATION";
            var vac = "VACCINATED";




            if (id == 15687459)
            {
                displayMessage += String.Format(details1);
                displayMessage += String.Format("\nSurname: Paul" + "\nFirst Name(s): Jake" + $"\nGender: {genderM}" + $"\nID: {id}" + "\nNext appointment date: 09-07-2022" + "\nEVDS vaccination number: YPB-3-5455DHF");
                displayMessage += String.Format("\n\n" + details3 + "\t\t\t" + details4 + "\t\t\t" + details5 + "\t\t\t" + details6 + "\t\t\t" + details7 + "\t\t\t" + details8);
                displayMessage += String.Format("\n" + vaccineDose1 + "\t\t\t" + vaccineName1 + "\t\t\t\t" + manufacturer1 + "\t\t\t\t" + "FC1562" + "\t\t\t\t" + "06-04-2022" + "\t\t\t" + location1);
                displayMessage += String.Format("\n" + vaccineDose2 + "\t\t\t" + vaccineName1 + "\t\t\t\t" + manufacturer1 + "\t\t\t\t" + "FC1485" + "\t\t\t\t" + "02-06-2022" + "\t\t\t" + location1);
                displayMessage += String.Format("\n\n" + details2);
                displayMessage += String.Format("\nSurname: Baker" + "\nFirst Name(s): Hannah" + $"\nGender: {genderF}");
                displayMessage += String.Format("\n\n" + vac);


            }
            else if (id == 15698432)
            {
                displayMessage += String.Format(details1);
                displayMessage += String.Format("\nSurname: Musk" + "\nFirst Name(s): Elon" + $"\nGender: {genderM}" + $"\nID: {id}" + "\nNext appointment date: 11-10-2022" + "\nEVDS vaccination number: JSB-7-8936ZHF");
                displayMessage += String.Format("\n\n" + details3 + "\t\t\t" + details4 + "\t\t\t\t" + details5 + "\t\t\t\t" + details6 + "\t\t\t\t" + details7 + "\t\t\t" + details8);
                displayMessage += String.Format("\n" + vaccineDose1 + "\t\t\t" + vaccineName2 + "\t\t\t" + manufacturer2 + "\t\t\t" + "FC1785" + "\t\t\t\t\t" + "01-03-2022" + "\t\t\t" + location4);
                displayMessage += String.Format("\n\n" + details2);
                displayMessage += String.Format("\nSurname: Donay" + "\nFirst Name(s): Stacey" + $"\nGender: {genderF}");
                displayMessage += String.Format("\n\n" + vac);


            }
            else if (id == 16579423)
            {
                displayMessage += String.Format(details1);
                displayMessage += String.Format("\nSurname: Arden" + "\nFirst Name(s): Elizabeth" + $"\nGender: {genderF}" + $"\nID: {id}" + "\nNext appointment date: 01-12-2022" + "\nEVDS vaccination number: NEP-15-3320LHF");
                displayMessage += String.Format("\n\n" + details3 + "\t\t\t" + details4 + "\t\t\t" + details5 + "\t\t\t" + details6 + "\t\t\t" + details7 + "\t\t\t" + details8);
                displayMessage += String.Format("\n" + vaccineDose1 + "\t\t\t" + vaccineName2 + "\t\t" + manufacturer2 + "\t\t" + "FC1398" + "\t\t\t\t" + "05-04-2022" + "\t\t\t" + location2);
                displayMessage += String.Format("\n" + vaccineDose2 + "\t\t\t" + vaccineName2 + "\t\t" + manufacturer2 + "\t\t" + "FC1876" + "\t\t\t\t" + "08-09-2022" + "\t\t\t" + location2);
                displayMessage += String.Format("\n\n" + details2);
                displayMessage += String.Format("\nSurname: Tom" + "\nFirst Name(s): Brady" + $"\nGender: {genderM}");
                displayMessage += String.Format("\n\n" + vac);


            }
            else if (id == 11245786)
            {
                displayMessage += String.Format(details1);
                displayMessage += String.Format("\nSurname: Bezzos" + "\nFirst Name(s): Jeff" + $"\nGender: {genderM}" + $"\nID: {id}" + "\nNext appointment date: 08-08-2022" + "\nEVDS vaccination number: ABC-1-2345DHF");
                displayMessage += String.Format("\n\n" + details3 + "\t\t\t" + details4 + "\t\t\t" + details5 + "\t\t\t" + details6 + "\t\t\t" + details7 + "\t\t\t" + details8);
                displayMessage += String.Format("\n" + vaccineDose1 + "\t\t\t" + vaccineName1 + "\t\t\t\t" + manufacturer1 + "\t\t\t\t" + "FC1599" + "\t\t\t\t" + "02-02-2022" + "\t\t\t" + location3);
                displayMessage += String.Format("\n" + vaccineDose2 + "\t\t\t" + vaccineName2 + "\t\t" + manufacturer2 + "\t\t" + "FC1785" + "\t\t\t\t" + "21-05-2022" + "\t\t\t" + location3);
                displayMessage += String.Format("\n" + vaccineDose3 + "\t\t\t" + vaccineName2 + "\t\t" + manufacturer2 + "\t\t" + "FC1785" + "\t\t\t\t" + "21-05-2022" + "\t\t\t" + location3);
                displayMessage += String.Format("\n\n" + details2);
                displayMessage += String.Format("\nSurname: Paul" + "\nFirst Name(s): Logan" + $"\nGender: {genderM}");
                displayMessage += String.Format("\n\n" + vac);

                

            }
            else if (id == 11154876)
            {
                

                displayMessage += String.Format(details1);
                displayMessage += String.Format("\nSurname: Gomez" + "\nFirst Name(s): Selena" + $"\nGender: {genderF}" + $"\nID: {id}" + "\nNext appointment date: 05-03-2022" + "\nEVDS vaccination number: ALS-8-1111DLF");
                displayMessage += String.Format("\n\n" + details3 + "\t\t\t" + details4 + "\t\t\t" + details5 + "\t\t\t" + details6 + "\t\t\t" + details7 + "\t\t\t" + details8);
                displayMessage += String.Format("\n" + vaccineDose1 + "\t\t\t" + vaccineName1 + "\t\t\t\t" + manufacturer1 + "\t\t\t\t" + "FC1562" + "\t\t\t\t" + "06-04-2022" + "\t\t\t" + location1);
                displayMessage += String.Format("\n\n" + details2);
                displayMessage += String.Format("\n" + "Surname: Baker" + "\nFirst Name(s): Hannah" + $"\nGender: {genderF}");
                displayMessage += String.Format("\n\n" + vac);



            }




           

            return new OkObjectResult(displayMessage);
    }
    }
}
